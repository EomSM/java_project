package 그래픽프로그램;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

import 클래스연습.계산기;

import java.awt.Color;

public class 계산기프로그램 {
	private static JTextField t2;
	private static JTextField t1;
	private static JTextField t3;

	public static void main(String[] args) {

		JFrame f = new JFrame();
		f.getContentPane().setBackground(new Color(46, 139, 87));
		f.getContentPane().setFont(new Font("굴림", Font.PLAIN, 30));
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("숫자1");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel.setBounds(53, 10, 141, 88);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("숫자2");
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(53, 95, 157, 88);
		f.getContentPane().add(lblNewLabel_1);

		t2 = new JTextField();
		t2.setFont(new Font("굴림", Font.PLAIN, 30));
		t2.setBounds(207, 114, 188, 63);
		f.getContentPane().add(t2);
		t2.setColumns(10);

		t1 = new JTextField();
		t1.setFont(new Font("굴림", Font.PLAIN, 30));
		t1.setColumns(10);
		t1.setBounds(207, 22, 188, 63);
		f.getContentPane().add(t1);

		JButton btnNewButton = new JButton("더하기");
		btnNewButton.setBackground(new Color(255, 215, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {// 버튼 더블클릭했더니 생기는 인터페이스 제공된 것임.
				System.out.println("더하기 버튼 클릭됨");
				String s1 = t1.getText(); // 텍스트필드 t1값을 string으로 가져옴
				String s2 = t2.getText(); // 텍스트필드 t2값을 string으로 가져옴
//				System.out.println(s1);
//				System.out.println(s2);

				int i1 = Integer.parseInt(s1);// 반환값이 있어야만 변수에 결과값을 넣을 수 있다. t1을 int값 i1으로
				int i2 = Integer.parseInt(s2);// t2을 int값 i2로 전환

				계산기 cal = new 계산기(); // 외부에 있는 계산기 클래스를 새로 불러온다.
				int result =cal.add(i1, i2); // 반환값이 있어야 프린트 가능, 변수에 결과값이 넣을 수 있다. i1과 i2를 cal의 add기능으로 처리한다.
				t3.setText("더한 값은 > " + result); //t3에 반환값인 result를 얹어 출력함.

			}
		});
		btnNewButton.setBounds(28, 289, 97, 162);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("곱하기");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("곱하기 버튼 클릭됨");
				String s1 = t1.getText();
				String s2 = t2.getText();
				int i1 = Integer.parseInt(s1);
				int i2 = Integer.parseInt(s2);

				계산기 cal = new 계산기();
				int result = cal.mul(i1, i2); // 타입 맞춰야 함 //5*10을 받아 반환
//				f.setTitle("곱한 값은 " + result);	
				t3.setText("곱한 값은 > " + result);

			}
		});

		btnNewButton_1.setBackground(new Color(255, 105, 180));
		btnNewButton_1.setBounds(246, 289, 97, 162);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("빼기");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				System.out.println("빼기 버튼 클릭됨");

				String s1 = t1.getText();
				String s2 = t2.getText();
				int i1 = Integer.parseInt(s1);
				int i2 = Integer.parseInt(s2);

				계산기 cal = new 계산기();
				int result = cal.minus(i1, i2);
				t3.setText("뺀 값은 > "+ result);
			}

		});

		btnNewButton_2.setBackground(new Color(255, 165, 0));
		btnNewButton_2.setBounds(137, 289, 97, 162);
		f.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("나누기");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("나누기 버튼 클릭됨");

				String s1 = t1.getText();
				String s2 = t2.getText();
				int i1 = Integer.parseInt(s1);
				int i2 = Integer.parseInt(s2);

				계산기 cal = new 계산기();
				int result = cal.div(i1, i2);
				t3.setText("나눈 값은 > "+ result);
				

			}
		});

		btnNewButton_3.setBackground(new Color(186, 85, 211));
		btnNewButton_3.setBounds(355, 289, 97, 162);
		f.getContentPane().add(btnNewButton_3);

		t3 = new JTextField();
		t3.setBackground(new Color(255, 255, 0));
		t3.setFont(new Font("굴림", Font.PLAIN, 30));
		t3.setColumns(10);
		t3.setBounds(53, 198, 342, 63);
		f.getContentPane().add(t3);

		f.setVisible(true);

	}
}

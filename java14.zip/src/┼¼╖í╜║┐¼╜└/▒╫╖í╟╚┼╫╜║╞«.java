package 클래스연습;



import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;

public class 그래픽테스트 {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(300, 300);
		
		JButton b = new JButton();
		b.setText("나를눌러요");
		b.setBackground(Color.red);
		f.add(b);
		
		Font font = new Font("궁서", 1, 50);//이름, 스타일, 사이즈 
		b.setFont(font);
		//타입, 개수, 순서 때문에 같은 메서드 이름을 다르게 활용해서 쓸 수 있다. 이 안에 있는 것만 써야 한다.
		
		
		f.setVisible(true);//boolean 값을 집어넣어라. t/f
		
		
	}

}

package 클래스연습;

public class 자동차를만들어사용해보자 {

	public static void main(String[] args) {
		// start 기능을 하게 해주는 main
		car c1 = new car();
		c1.color = "빨간색";
		car c2 = new car();
		c2.color = "파란색";// 1, 2가 따로 복사가 된다
//c1, c2는 참조형 변수로 주소가 들어있다 ->주소가 변수에 들어있으므로 메서드를 쓸 수 있다
		c1.run();
		c2.up();
		
	}

}

package 클래스연습;

public class 카페에서계산기사용 {

	public static void main(String[] args) {
		int coffeePrice = 4600;
		int juicePrice = 4000;
		int coffeeCount = 5; // 커피 주문수
		int juiceCount = 3; // 주스 주문수

		// 전체 몇 잔을 주문했는가?
		계산기 cal = new 계산기();
		cal.add(coffeeCount, juiceCount);

		// 커피값 전체 금액은?//그래픽의 경우를 제외하고는 한번 불러서 계속 사용 가능.
		// 주스값 전체
		int coffee = cal.mul(coffeeCount, coffeePrice); // 커피변수 안에 저장
		int juice = cal.mul(juiceCount, juicePrice);

		// 전체 금액은
		cal.add(coffee, juice);
		// x값에 17줄, y값에 18줄이 들어가야 하는 상황:
		// mul의 result를 add하려 함.
		// = 계산기 값을 카페로 "반환""Return"함.
		// 메서드를 사용할 때 =>메서드를 "호출""콜Call"할 때
		// 그 처리 결과값을 가지고 와서 다시 사용해야 하는 경우 : "리턴을 받아온다"라고 함.
		// 호출했을 때 그 값이 필요한 경우 반환을 받아와야 한다.
		// 커피값과 주스값을 입력값으로 계산기에 주면서 더해달라고 함 = 35000원 결과 나옴.

		int hour = cal.getHour();
		System.out.println("현재시각은 " + hour);

	}

}

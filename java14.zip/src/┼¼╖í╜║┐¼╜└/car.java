package 클래스연습;

public class car {
//다른 곳에서 가져다가 연습: 이젠 main 굳이 안 넣어도 됨.
	// 속성,성질: 색, 등 멤버변수
	String color;

	// 동작: 멤버메서드, 달리다, 속도를 높이다.
	public void run() {
		System.out.println("차가 달린다");
	};//얘를 썼을 때의 기능을 뒤에 {}로 묶어줌
	
	public void up() {
		System.out.println("차가 가속한다");
	}
	
}

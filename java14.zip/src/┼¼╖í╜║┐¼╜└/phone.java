package 클래스연습;

public class phone {

	String color;
	int size;

	public void call() {
		System.out.println("통화하다");
	}

	public void internet(String x, int y, String z ) {
		System.out.println(x+"에 " + z+ "에 " + y+ "시간 서핑하다");
	}

	public void text(String x, String y, int z) { //변수의 타입, 순서, 개수 중요
		System.out.println(x + "에게 " + y + "이라고 " + z + "시에 문자하다");
	//	System.out.println("x에게 y라고 z시에 문자하다");

	}
}

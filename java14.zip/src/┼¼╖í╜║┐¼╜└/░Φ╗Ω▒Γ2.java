package 클래스연습;

public class 계산기2 {
//메서드 중심
	public void add(int x, int y) { // 중간에 입력값을 받을 수 있게 매게체 저장. 그걸 가지고 계산하게.
		System.out.println("두 수의 합은 : " + (x + y));
		// ()를 해야 하는 이유: Str에 그냥 결합시켜버리지 않고 뒤의 사칙연산부터 할 수 있게
		System.out.println("계산기로 더하다.");
		// 메서드의 입력값이 있는 경우,
		// 입력되는 값의 타입과 수에 따라 변수를 만들어 주어야 한다. int str double 등.
		// 전달되는 값을 받아서 저장해두었다가 꺼내서 계산할 수 있다.
	}

	public void minus(int x, int y) {
		System.out.println("두 수의 차는 : " + (x - y));
		System.out.println("계산기로 빼다.");
	}

	//여기의 x,y를 중간 값 전달 받은 변수 = 매개체 역할 = 매개변수parametner파라메터라 부름.
	//전달받은 값이 2개이면 매개변수 2개 만들어야 함
	//전달받은 값이 순서대로 매개변수에 저장됨.
	//이렇게 저장된 값을 가지고 매서드 내에서 처리하게 됨.

	
	public void mul() {
		System.out.println("계산기로 곱하다.");
	}

	public void div() {
		System.out.println("계산기로 나누다.");
	}

}

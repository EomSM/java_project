package 클래스연습;

public class 전화기만들어사용하자 {

	public static void main(String[] args) {

		phone p1 = new phone();
	//	phone p2 = new phone();
		// 참조용변수 p1, p1의 멤버변수(사이즈, 칼라): 3개가 됨.
		// size, color 멤버변수가 복사됨
		// size= 기본형변수, color = 참조형변수

		p1.call();
		p1.internet("네이버", 10, "어제");
		
		p1.text("철수", "굿모닝", 10);
		p1.color = "검정색";
		p1.size = 11;
		System.out.println("전화기 색:" + p1.color);
		System.out.println("전화기 크기:" + p1.size);

		p1.text("길동이", "굿애프터눈", 15);
		//기능은 한 번, 내용은 여러 개일 때  x,y,z 파라미터, 매개변수 역할을 함.
		//파라미터 가 두 개= 첫번째것의 정보가 모자랐을 때에도 두번째꺼로 수정 정정 변경 가능. 다양한 입력값 > for 판단
		//파라미터 중에는 절대 내가 조절 불가능한 경우도 있다
		//
	}

}

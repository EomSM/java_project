package 정리문제;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 계산기그래픽 {
	private static JTextField t1;
	private static JTextField t2;
	private static JTextField t3;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame f = new JFrame();
		f.setSize(600, 400);
		f.getContentPane().setLayout(null);

		JLabel 숫자1 = new JLabel("숫자1");
		숫자1.setBounds(57, 82, 103, 34);
		f.getContentPane().add(숫자1);

		JLabel 숫자2 = new JLabel("숫자2");
		숫자2.setBounds(57, 154, 103, 34);
		f.getContentPane().add(숫자2);

		t1 = new JTextField();
		t1.setBounds(193, 70, 319, 60);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(193, 142, 319, 60);
		f.getContentPane().add(t2);

		t3 = new JTextField();
		t3.setBounds(12, 230, 511, 60);
		f.getContentPane().add(t3);
		t3.setColumns(10);

		JButton btnNewButton = new JButton("+");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("더하기 : ");
				String s1 = t1.getText();
				String s2 = t2.getText();
				int i1 = Integer.parseInt(s1);
				int i2 = Integer.parseInt(s2);
				계산기 cal = new 계산기();//계산기 불러오기
				int result = cal.add(i1, i2);
				t3.setText("더한 값 : " + result); 
				// string으로 받아야 해서 int인 result만 남기면 오류 남..

			}
		});
		btnNewButton.setBounds(35, 331, 97, 23);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("-");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("빼기 : ");
				int i1 = Integer.parseInt(t1.getText()); //t1에 입력된 str값을 int로 변환해서 i1 변수에 저장
				int i2 = Integer.parseInt(t2.getText());
				계산기 cal = new 계산기();
				int result = cal.minus(i1, i2);//i1-i2를 result값에 저장
				t3.setText("뺀 값: " + result);//result 값을 t3에 출력
			}
		});
		btnNewButton_1.setBounds(178, 331, 97, 23);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("x");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("곱하기 : ");
				int i1 = Integer.parseInt(t1.getText());
				int i2 = Integer.parseInt(t2.getText());
				계산기 cal = new 계산기();
				int result = cal.mul(i1, i2);
				t3.setText("곱한 값 : " + result);
			}
		});
		btnNewButton_2.setBounds(329, 331, 97, 23);
		f.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("/");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("나누기: ");
				int i1 = Integer.parseInt(t1.getText());
				int i2 = Integer.parseInt(t2.getText());
				계산기 cal = new 계산기();
				int result = cal.div(i1, i2);
				t3.setText("나눈 값: " + result);
			}
		});
		btnNewButton_3.setBounds(475, 331, 97, 23);
		f.getContentPane().add(btnNewButton_3);

		
		f.setVisible(true);

	}

}

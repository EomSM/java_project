package shop;

import java.util.Date;

public class 계산기 {
	public int getHour() { // int로 바꿔줘야 리턴 할 때에 에러가 안 난다
		Date date = new Date();
		int result = date.getHours();// 12
		return result;
		// 현재시각 date
	}

	public int add(int x, int y) {
		int result = x + y;
		System.out.println(result);
		return result;
	}
	// 메서드에서 선언된 변수는 매서드 안에서만 사용 가능하다. 메서드 범위 지역 안에서만 사용 가능하다.
	// 지역변수 = 로컬변수. <=> 글로벌변수, 전역변수
	// 그래서 요 안에 있는 result나 x, y가 아래에서 반복되어도 ok

	public int minus(int x, int y) { // void는 리턴이 없다
		int result = x - y;
		System.out.println(result);
		return result;
	}

	public int mul(int x, int y) {
		int result = x * y;
		System.out.println("곱한 값은 " + result);
		return result;// 반환한다. > void가 아니라 그 위치에 result 값의 타입을 써준다.
	}// 반환되는 타입은 기본형; 참조형 다 된다.
		// return은 마지막 줄에 와야 함.

	public int div(int x, int y) {
		int result = x / y;
		System.out.println(result);
		return result;
	}

}

package snippet;

public class Snippet {
	select * from member
	
}


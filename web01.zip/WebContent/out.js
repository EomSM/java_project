/**주석
 * 
 */
function welcome() {
	alert ("welcome !")
}
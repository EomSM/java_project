package com.mega.mvc38;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component //BbsDao dao = new BbsDao(); 싱글톤 인젝션(주입, injection)
public class BbsDAO {

	@Autowired
	SqlSessionTemplate my;

	
	public List<BbsVO> all() {
		return my.selectList("bbs.all");
	}
	
	public void create(BbsVO bag) throws Exception {
		my.insert("bbs.insert", bag);
	}

	public void delete(String id) throws Exception {
		my.delete("bbs.delete", id);
	}

	public void update(String id) throws Exception{
		my.update("bbs.update", id); 
	}

	public BbsVO read(BbsVO bbsVO) {
		BbsVO vo =my.selectOne("bbs.select", bbsVO);
		return vo;
		
	}//하나만 검색

	

}

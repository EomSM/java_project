package com.mega.mvc38;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BbsController {

	// @Controller 1. 스프링 프레임워크에 해당 클래스를 컨트롤러 역할을 하도록 등록 2. 싱글톤 객체로 생성

	@Autowired // 싱글톤으로 만든 주소
	BbsDAO dao;

	@RequestMapping("bbsinsert")
	public void insert(BbsVO bbsVO) throws Exception {
		// bbsVO를 model 속성으로 자동 등록해 줌.
		dao.create(bbsVO);
		// model.addattribute)()
	}

	@RequestMapping("select")
	public void select(BbsVO bbsVO, Model model) {
		BbsVO vo = dao.read(bbsVO);
		// views까지 검색된 정보 가지고 가야 함.
		// model으로 속성으로만 등록하면 됨.
		model.addAttribute("vo", vo); // addAllAttribute 아님! 확인하고 넣기!
	}
	
	@RequestMapping("all")
	public void all(Model model) {
		List<BbsVO> list =dao.all();
		System.out.println("목록의 개수 : " + list.size() + "개가 있음. ==========");
		model.addAttribute("list", list);
	}
	
}

package com.mega.mvc38;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class ProductDAO {

	@Autowired
	SqlSessionTemplate my;
	//오토와이어드로 마이바티스 끼우기

	public ProductVO select(ProductVO productVO) {
		return my.selectOne("product.select", productVO);
	}
	public void create(ProductVO productVO) throws Exception {
		my.insert("product.insert", productVO);
	}

	public void delete(String id) throws Exception { 
		my.delete("product.delete", id);
	}

	public void update(String id) throws Exception{
		my.update("product.update", id); 
	}


}

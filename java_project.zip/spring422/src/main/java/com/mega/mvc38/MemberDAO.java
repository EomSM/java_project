package com.mega.mvc38;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MemberDAO {

//마이바티스 싱글톤을 쓰기 위해 주소를 주입할 것임.

	@Autowired
	SqlSessionTemplate my;
	// MyBatis가 맡을 것
	
	public MemberVO login(MemberVO memberVO) {
		return my.selectOne("member.login", memberVO); //1 row select
		//mapper파일의 namespace이름. 태그의 id와 일치해야.
		//<mapper namespace="//member//">
		//<select id="login">
		
	}

	public List<MemberVO> all2(){
		return my.selectList("member.all2");
	}	
	
	public List<MemberVO> all3(){
		return my.selectList("member.all3");
	}	
	
	public MemberVO select(MemberVO memberVO) {
		return my.selectOne("member.select", memberVO);
	}

	public void create(MemberVO memberVO) throws Exception {
		my.insert("member.insert", memberVO);
	}

	public void delete(MemberVO memberVO) throws Exception {
		my.delete("member.delete", memberVO);

	}

	public void update() {

	}

	public void read() {

	}


	}



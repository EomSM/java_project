package com.mega.mvc38;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class TextService {

	public int text(String tel) {

		// 랜덤값 6자리 만들어 controller에 리턴
		Random r = new Random();
		int num2 = r.nextInt(900000) + 100000;// 다섯글자로.
		return num2;
	}


}

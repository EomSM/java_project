package com.mega.mvc38;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PersonDAO {

//마이바티스 싱글톤을 쓰기 위해 주소를 주입할 것임.

	@Autowired
	SqlSessionTemplate my;
	// MyBatis가 맡을 것
	

	public void create(PersonVO personVO) throws Exception {
		my.insert("person.insert", personVO);
	}

	}



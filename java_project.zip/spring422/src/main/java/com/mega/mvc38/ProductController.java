package com.mega.mvc38;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProductController {

	// @Controller 1. 스프링 프레임워크에 해당 클래스를 컨트롤러 역할을 하도록 등록 2. 싱글톤 객체로 생성

	@Autowired // 싱글톤으로 만든 주소
	ProductDAO dao;

	@RequestMapping("select3")
	public void select(ProductVO productVO, Model model) throws Exception {
		ProductVO vo = dao.select(productVO);
		model.addAttribute("vo3", vo);
	}

	@RequestMapping("insert11")
	public void insert(ProductVO vo) throws Exception {
		dao.create(vo);
	}

}

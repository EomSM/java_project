package com.mega.mvc38;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PersonController {

	@Autowired
	PersonDAO dao;
	
	@RequestMapping("insertperson")
	public void insert(PersonVO bag) throws Exception {
		// public void insert(String id, String pw, String name, String tel) {
		// 컨트롤러에 있는 메서드에 변수를 선언하면, 스프링이 객체를 생성해준다.
		// MemberDAO dao = new MemberDAO();를 내부적으로 처리한 상태
		dao.create(bag);

	}
}

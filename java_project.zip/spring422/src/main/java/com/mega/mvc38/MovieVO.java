package com.mega.mvc38;

public class MovieVO {
	String title;
	int Price;

	@Override
	public String toString() {
		return "MovieVO [title=" + title + ", Price=" + Price + "]";
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}

}

package com.mega.mvc38;

public class ComputerVO {

	int cprice;
	String ctype; 		
	int mprice;
	String mtype;
	int tamount;
	
	public int gettamout() {
		return gettamout();
	}
	
	public void settamount(int tamount) {
		this.tamount = tamount;
	}
	 
	public int getCprice() {
		return cprice;
	}
	public void setCprice(int cprice) {
		this.cprice = cprice;
	}
	public String getCtype() {
		return ctype;
	}
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}
	public int getMprice() {
		return mprice;
	}
	public void setMprice(int mprice) {
		this.mprice = mprice;
	}
	public String getMtype() {
		return mtype;
	}
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}

	@Override
	public String toString() {
		return "ComputerVO [cprice=" + cprice + ", ctype=" + ctype + ", mprice=" + mprice + ", mtype=" + mtype
				+ ", tamount=" + tamount + "]";
	}

	
	
	
}

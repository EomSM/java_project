package com.mega.mvc38;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MemberController {

	@Autowired
	MemberDAO dao;

	@RequestMapping("sunday")
	public void sunday() {

	}

	@RequestMapping("select2")
	public void select2(MemberVO memberVO, Model model) throws Exception {
		MemberVO vo = dao.select(memberVO);
		model.addAttribute("vo2", vo);
		// jdbc 프로그램 절차 4단계
	}

	@RequestMapping("all2")
	public void all2(Model model) {
		List<MemberVO> list = dao.all2();
		System.out.println("목록의 개수 : " + list.size() + "개가 있음. ==========");
		model.addAttribute("list", list);
	}

//	@RequestMapping("all3")
//	@ResponseBody
//	public List<MemberVO> all3() {
//		List<MemberVO> all3 = dao.all3();
//		return all3;
//	}
//	
	@RequestMapping("all3")
	@ResponseBody
public String all3(String food) {
	if (food.equals("아이스크림")) {
		return "편의점으로";
	} else {
		return "식당으로";
	}	
		
}
	
//	@RequestMapping("delete.mega")
//	public void delete(MemberVO memberVO, Model model) throws Exception {
//		System.out.println("금번엔 삭제하기 위해 내가 호출됨");
//		System.out.println("컨트롤하는 메서드");
//		System.out.println("컨트롤러에서 받은 아이디는 : " + id);
//		dao.delete(id);
//	}

	@RequestMapping("insert.mega")
	public void insert(MemberVO bag) throws Exception {
		// public void insert(String id, String pw, String name, String tel) {
		// 컨트롤러에 있는 메서드에 변수를 선언하면, 스프링이 객체를 생성해준다.
		// MemberDAO dao = new MemberDAO();를 내부적으로 처리한 상태
		dao.create(bag);

	}

	@RequestMapping("login")
	public String login(MemberVO memberVO, HttpSession session) {
		// 넘어갈 페이지가 다르다는 점을 Spring에 알려줘야 함 : 반환값 있게: x void

		MemberVO vo = dao.login(memberVO);
		if (vo != null) {
			System.out.println("해당 id/pw 있음");
			session.setAttribute("userId", vo.getId());
			return "ok";
		} else {
			System.out.println("해당 id/pw 없음");
			return "no";
		}

	}

}

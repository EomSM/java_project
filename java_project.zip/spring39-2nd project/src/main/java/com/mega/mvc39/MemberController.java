package com.mega.mvc39;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {

	@Autowired
	MemberDAO dao;

	@RequestMapping("memberinsert.mega")
	public void insert(MemberVO vo) throws Exception {
		// date를 string으로 받는 vo에 먼저 넣기
		System.out.println("test----------------------");
		System.out.println("test===================" + vo);
		dao.create(vo);
	}
	/*
	 * MemberVO vo2 = new MemberVO(); //string -date를 다시 date로 넣는 vo에 넣기 int year =
	 * Integer.parseInt(vo.getBirthdate().split("-")[0]);//생년월일 - 단위로 split 하고
	 * integer로 처리. int month = Integer.parseInt(vo.getBirthdate().split("-")[1]);
	 * int day = Integer.parseInt(vo.getBirthdate().split("-")[2]); Date date = new
	 * Date(year, month, day); System.out.println(vo2);
	 */


	// 아래: 원래 버전 코드
	// 의문 : 왜 입력값이 mid가 아닐까? 계속 나던 오류: mid 어떻게 되냐?- 위 버전: +redirect,
	@RequestMapping("memberdelete.mega")
	public void delete(MemberDAO memberDAO) throws Exception {
		System.out.println("test----------------------");
		System.out.println("test===================" + memberDAO);
		dao.delete(memberDAO);
	}
	
	/* @RequestMapping("memberdelete")
	 * public void delete(String mid) throws Exception {
	 * System.out.println("test----------------------");
	 * System.out.println("test===================" + mid); dao.delete(mid); return
	 */

	@RequestMapping("memberlogin")
	public String login(MemberVO memberVO, HttpSession session) {
		// 넘어갈 페이지가 다르다는 점을 Spring에 알려줘야 함 : 반환값 있게: x void

		MemberVO vo = dao.login(memberVO);
		if (vo != null) {
			System.out.println("해당 id/pw 있음");
			session.setAttribute("Mid", vo.getMid());
			return "memberlogin";
			// return "redirect:main.jsp";

		} else {
			System.out.println("해당 id/pw 없음");
			return "no";
		}

	}

	@RequestMapping("my_info")
	public void select(MemberVO memberVO) {
		dao.read(memberVO);
	}

}

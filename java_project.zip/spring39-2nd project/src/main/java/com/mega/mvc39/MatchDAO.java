package com.mega.mvc39;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MatchDAO {

@Autowired
SqlSessionTemplate my;

public void create(MatchVO matchVO) {
	my.insert("match.insert", matchVO);
}

public MatchVO login(MatchVO matchVO) {
	return my.selectOne("match.login", matchVO); //1 row select
	//mapper파일의 namespace이름. 태그의 id와 일치해야.
	//<mapper namespace="//member//">
	//<select id="login">
}

public void read() {
	
}

public void update() {
	
}

public void delete() {
	
}
	
	
}

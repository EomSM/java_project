package shop;

import javax.swing.JOptionPane;

public class DB전담 {
//CRUD 기능을 구현해야 한다!//create read update delete 
	// 회원정보라면

	// 회원가입 시
	public void create() {
		// db접속 
		// sql문 만들어서 . insert!
		System.out.println("db에 회원가입 완료");
		// db로 전송
	}

	// 회원정보 보기
	public void read() {
		// db접속
		// sql문 만들어서 . select
		// db로 전송

	}

	// 회원정보 수정
	public void update() {
		// db접속
		// sql문 만들어서 . update!
		// db로 전송

	}

	// 회원 탈퇴 
	public void delete() {
		// db접속
		// sql문 만들어서 . delete!
		// db로 전송

	}
}

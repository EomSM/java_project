package shop;

public class 결제DB {//ip, port
	public void create() {
		// db접속 
		// sql문 만들어서 . insert!
		System.out.println("주문결제성공");
		// db로 전송
	}

	public void idCheck() {
		// db접속
		// sql문 만들어서 . select
		// db로 전송
	}

	public void login() {
		// db접속
		// sql문 만들어서 . select
		// db로 전송
	}

	public void read() {
		// db접속 
		// sql문 만들어서 . insert!
		// db로 전송
	}

	public void update() {
		// db접속 
		// sql문 만들어서 . insert!
		// db로 전송
	}

	public void delete() {
		// db접속 
		// sql문 만들어서 . insert!
		// db로 전송
	}

}
